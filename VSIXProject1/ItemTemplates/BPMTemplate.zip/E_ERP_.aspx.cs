﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Specialized;
using Pkurg.PWorld.Business.Manage;
using Pkurg.PWorld.Entities;
using Pkurg.PWorld.Business.Permission;
using System.Data;
using SourceCode.Workflow.Client;
using Pkurg.PWorldBPM.Business;

using Pkurg.PWorldBPM.Common.Log;
using Pkurg.BPM.Entities;
using Pkurg.PWorld.Business.Common;
using Pkurg.PWorldBPM.Business.Workflow;
using System.Diagnostics;
using System.Xml;
using System.Net;
using System.IO;
using Pkurg.PWorldBPM.Business.AttachmentMan;
using System.Text;
using Pkurg.PWorldBPM.Business.BIZ.ERP;
using Pkurg.PWorldBPM.Entites.BIZ.ERP;


public partial class Workflow_EditPage_E_$safeitemname$ : UPageBase
{
    /// <summary>
    /// 加载表单
    /// </summary>
    private void InitFormData()
    {

    }

    /// <summary>
    /// 保存表单
    /// </summary>
    /// <returns></returns>
    private PaymentApplicationInfo SaveFormData()
    {
        bool isEdit = false;
        PaymentApplicationInfo info = null;
        try
        {
            info = PaymentApplication.GetPaymentApplicationInfo(FormId);
            if (info == null)
            {
                info = new PaymentApplicationInfo();
                info.FormId = FormId;
                info.ErpFormId = HttpContext.Current.Request["erpFormId"];
                info.ErpFormType = HttpContext.Current.Request["erpFormType"];
                //info.StartDeptId = HttpContext.Current.Request["startDeptId"];
                info.StartDeptId = ddlDepartName.SelectedItem.Value;
                info.IsOverContract = cblisoverCotract.Checked ? 1 : 0;
                info.IsCheckedChairman = cbChairman.Checked ? 1 : 0;
            }
            else
            {
                isEdit = true;
                info.FormId = FormId;
                info.IsOverContract = cblisoverCotract.Checked ? 1 : 0;
                info.StartDeptId = ddlDepartName.SelectedItem.Value;
                info.IsCheckedChairman = cbChairman.Checked ? 1 : 0;
                info.ApproveResult = "";
                //info.ErpFormId = HttpContext.Current.Request["erpFormId"];
                //info.ErpFormType = HttpContext.Current.Request["erpFormType"];
                //info.StartDeptId = HttpContext.Current.Request["startDeptId"];
            }
            StringBuilder cbDatas = new StringBuilder();
            foreach (ListItem item in cbRelatonUsers.Items)
            {
                if (item.Selected)
                {
                    cbDatas.AppendFormat("{0},", item.Value);
                }

            }
            info.LeadersSelected = cbDatas.ToString().Trim(',');

            if (!isEdit)
            {
                PaymentApplication.InsertPaymentApplication(info);
            }
            else
            {
                PaymentApplication.UpdatePaymentApplication(info);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return info;
    }

    /// <summary>
    /// 设置流程参数
    /// </summary>
    /// <returns></returns>
    private NameValueCollection SetWFParams()
    {
        string startDeptId = ddlDepartName.SelectedItem.Value;

        NameValueCollection dataFields = new NameValueCollection();
        Department deptInfo = new Pkurg.PWorld.Services.DepartmentService().GetByDepartCode(startDeptId);
        string companyCode = deptInfo.DepartCode.Substring(0, deptInfo.DepartCode.LastIndexOf('-'));

        StringBuilder firstFieldBuilder = new StringBuilder();
        foreach (ListItem item in cbRelatonUsers.Items)
        {
            if (item.Selected)
            {
                firstFieldBuilder.AppendFormat("K2:Founder\\{0},", item.Value);
            }
        }
        string firstField = firstFieldBuilder.ToString().Trim(',');
        dataFields.Add("RelatedPersonnel", !string.IsNullOrEmpty(firstField) ? firstField : "noapprovers");


        bool flag = true;//标记datafields内的变量是否均赋值
        //城市公司部门负责人
        if (string.IsNullOrEmpty(GetRoleUsers(deptInfo.DepartCode, "部门负责人")))
        {
            flag = false;
            Alert(Page, "发起部门负责人尚未配置！");
        }
        else
        {
            dataFields.Add("DeptManager", GetRoleUsers(deptInfo.DepartCode, "部门负责人"));
        }

        StringBuilder leaders = new StringBuilder();
        StringBuilder Viceleaders = new StringBuilder();
        StringBuilder deptsofGroup = new StringBuilder();

        StringBuilder leaderofgroup = new StringBuilder();
        StringBuilder AssistantPresident = new StringBuilder();
        StringBuilder VicePresident = new StringBuilder();

        dataFields.Add("CounterSignUsers", Countersign1.GetCounterSignUsers());
        List<string> countersigns = Countersign1.Result.Split(',').ToList();
        foreach (var item in countersigns)
        {
            if (!string.IsNullOrEmpty(item))
            {
                if (string.IsNullOrEmpty(GetRoleUsers(item, "部门负责人")))
                {
                    flag = false;
                    Alert(Page, item + "会签部门负责人尚未配置！");
                }
            }
        }

        string financialManagementDepartCode = "";
        Department financialManagementDepartmentInfo = new BFPmsUserRoleDepartment().GetDeptByCurrentDeptCodeAndOtherDeptName(deptInfo.DepartCode, "财务管理部");
        if (financialManagementDepartmentInfo == null)
        {
            flag = false;
            Alert(Page, "财务管理部门负责人尚未配置！");
        }
        else
        {
            string financialManagementDepartmentInfoManager = GetRoleUsers(financialManagementDepartmentInfo.DepartCode, "部门负责人");
            if (string.IsNullOrEmpty(financialManagementDepartmentInfoManager))
            {
                flag = false;
                Alert(Page, "财务管理部门负责人尚未配置！");
            }
            else
            {
                dataFields.Add("financialManagement", FilterDataField(financialManagementDepartmentInfoManager));
                ///加入到会签
                financialManagementDepartCode = financialManagementDepartmentInfo.DepartCode;
                countersigns.Add(financialManagementDepartCode);

                ///
                if (string.IsNullOrEmpty(GetRoleUsers(financialManagementDepartCode, "主管副总裁")))
                {
                    flag = false;
                    Alert(Page, "财务管理部门主管副总裁尚未配置！");
                }
                else
                {
                    dataFields.Add("financialManagementViceleaders", GetRoleUsers(financialManagementDepartCode, "主管副总裁"));
                }
            }
        }

        countersigns.Add(startDeptId);

        foreach (var item in countersigns)
        {
            string leadersTmp = GetRoleUsers(item, "主管助理总裁");
            if (!leaders.ToString().Contains(leadersTmp))
            {
                leaders.AppendFormat("{0},", leadersTmp);
            }
            if (item != financialManagementDepartCode)
            {
                string ViceleadersTmp = GetRoleUsers(item, "主管副总裁");
                if (!Viceleaders.ToString().Contains(ViceleadersTmp))
                {
                    Viceleaders.AppendFormat("{0},", ViceleadersTmp);
                }
            }
            string deptsofGroupTmp = GetRoleDepts(item, "集团主管部门");
            if (!deptsofGroup.ToString().Contains(deptsofGroupTmp))
            {
                deptsofGroup.AppendFormat("{0},", deptsofGroupTmp);
            }
        }



        dataFields.Add("leaders", FilterDataField(leaders));
        dataFields.Add("Viceleaders", FilterDataField(Viceleaders));
        //城市公司总裁
        if (string.IsNullOrEmpty(GetRoleUsers(companyCode, "总裁")))
        {
            flag = false;
            Alert(Page, "公司总裁尚未配置！");
        }
        else
        {
            dataFields.Add("CEO", GetRoleUsers(companyCode, "总裁"));
        }

        if (cbChairman.Checked)
        {
            dataFields.Add("chairman", FilterDataField(GetRoleUsers(companyCode, "董事长")));
        }
        else
        {
            dataFields.Add("chairman", "noapprovers");
        }
        dataFields.Add("StandingViceCEO", FilterDataField(GetRoleUsers(companyCode, "常务副总裁")));


        ///集团人员
        foreach (var item in deptsofGroup.ToString().Trim(',').Split(','))
        {
            string leaderofgroupTmp = GetRoleUsers(item, "部门负责人");
            if (!leaderofgroup.ToString().Contains(leaderofgroupTmp))
            {
                leaderofgroup.AppendFormat("{0},", leaderofgroupTmp);
            }
            string AssistantPresidentTmp = GetRoleUsers(item, "主管助理总裁");
            if (!AssistantPresident.ToString().Contains(AssistantPresidentTmp))
            {
                AssistantPresident.AppendFormat("{0},", AssistantPresidentTmp);
            }
            string VicePresidentTmp = GetRoleUsers(item, "主管副总裁");
            if (!VicePresident.ToString().Contains(VicePresidentTmp))
            {
                VicePresident.AppendFormat("{0},", VicePresidentTmp);
            }
        }

        dataFields.Add("leadersofgroup", FilterDataField(leaderofgroup));
        dataFields.Add("AssistantPresident", FilterDataField(AssistantPresident));
        dataFields.Add("VicePresident", FilterDataField(VicePresident));
        //集团总裁
        if (string.IsNullOrEmpty(GetRoleUsers("B04-D319", "总裁")))
        {
            flag = false;
            Alert(Page, "集团CEO尚未配置！");
        }
        else
        {
            dataFields.Add("CEOGroup", GetRoleUsers("B04-D319", "总裁"));
        }

        dataFields.Add("IsOverContract", cblisoverCotract.Checked ? "1" : "0");
        dataFields.Add("IsPass", "1");

        if (!flag)
        {
            dataFields = null;
        }
        return dataFields;
    }

    private string FilterDataField(string dataField_old)
    {
        string dataField = dataField_old.Trim(',');
        if (string.IsNullOrEmpty(dataField))
        {
            dataField = "noapprovers";
        }
        return dataField;
    }
    private string FilterDataField(StringBuilder dataField_old)
    {
        return FilterDataField(dataField_old.ToString().Trim(','));
    }


    private string GetRoleDepts(string item, string role)
    {
        StringBuilder dataInfos = new StringBuilder();
        BFCountersignRoleDepartment counterSignHelper = new BFCountersignRoleDepartment();
        DataTable dtDept = counterSignHelper.GetSelectCountersignDepartment(item, role);
        if (dtDept != null && dtDept.Rows.Count != 0)
        {
            foreach (DataRow rowItem in dtDept.Rows)
            {
                dataInfos.AppendFormat("{0},", rowItem["DepartCode"].ToString());
            }
        }
        return dataInfos.ToString().Trim(',');
    }

    private static string GetRoleUsers(string dept, string roleName)
    {
        BFPmsUserRoleDepartment bfurd = new BFPmsUserRoleDepartment();
        StringBuilder dataInfos = new StringBuilder();
        DataTable dtDept = bfurd.GetSelectRoleUser(dept, roleName);
        if (dtDept != null && dtDept.Rows.Count != 0)
        {
            foreach (DataRow rowItem in dtDept.Rows)
            {
                dataInfos.AppendFormat("K2:Founder\\{0},", rowItem["LoginName"].ToString());
            }
        }
        return dataInfos.ToString().Trim(',');
    }

    #region 整合--by zwx

    public string ContractID = null;

    public string FormId
    {
        get
        {
            return ViewState["FormID"].ToString();
        }
        set
        {
            ViewState["FormID"] = value;
        }
    }

    public string StartDeptId
    {
        get
        {
            return ViewState["StartDeptId"].ToString();
        }
        set
        {
            ViewState["StartDeptId"] = value;
        }
    }
    
    public WF_InstructionOfPKURG wf_Instruction = new WF_InstructionOfPKURG();
    WF_WorkFlowInstance wf_WorkFlowInstance = new WF_WorkFlowInstance();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            InitStartDeptment();

            if (!string.IsNullOrEmpty(Request.QueryString["id"]))
            {
                WorkFlowInstance info = new WF_WorkFlowInstance().GetWorkFlowInstanceById(Request.QueryString["id"]);
                FormId = info.FormId;
                InitFormData();

                SetUserControlInstance();
            }
            else
            {
                string erpFormId = HttpContext.Current.Request["erpFormId"];
                string erpFormType = HttpContext.Current.Request["erpFormType"];

                if (string.IsNullOrEmpty(erpFormId)
               || string.IsNullOrEmpty(erpFormType))
                {
                    //参数错误
                    ExceptionHander.GoToErrorPage();
                    return;
                }

                ContractID = BPMHelp.GetSerialNumber("ERP_FK_");
                FormId = ContractID;
                StartDeptId = ddlDepartName.SelectedItem.Value;
                LoadRelationPerson();
                Countersign1.CounterSignDeptId = StartDeptId;
            }
        }
    }

    private void SetUserControlInstance()
    {
        WorkFlowInstance workFlowInstance = wf_WorkFlowInstance.GetWorkFlowInstanceByFormId(FormId);
        FlowRelated1.ProcId = workFlowInstance.InstanceId;
        Countersign1.ProcId = workFlowInstance.InstanceId;
        UploadAttachments1.ProcId = workFlowInstance.InstanceId;
        hfInstanceId.Value = workFlowInstance.InstanceId;
    }

    private bool SaveWorkFlowInstance(string WfStatus, DateTime? SumitTime, string WfInstanceId)
    {
        bool result = false;
        WorkFlowInstance workFlowInstance = null;
        try
        {
            workFlowInstance = wf_WorkFlowInstance.GetWorkFlowInstanceByFormId(FormId);
            bool isEdit = false;
            if (workFlowInstance == null)
            {
                workFlowInstance = new WorkFlowInstance();
                workFlowInstance.InstanceId = Guid.NewGuid().ToString();
                workFlowInstance.CreateAtTime = DateTime.Now;
                workFlowInstance.AppId = "10105";
                workFlowInstance.CreateDeptCode = CurrentEmployee.DepartCode;
                workFlowInstance.CreateDeptName = CurrentEmployee.DepartName;
                workFlowInstance.CreateByUserCode = CurrentEmployee.EmployeeCode;
                workFlowInstance.CreateByUserName = CurrentEmployee.EmployeeName;
                workFlowInstance.FormTitle = PaymentApplication_Common.GetErpFormTitle(this);
            }
            else
            {
                isEdit = true;
                workFlowInstance.UpdateByUserCode = CurrentEmployee.EmployeeCode;
                workFlowInstance.UpdateByUserName = CurrentEmployee.EmployeeName;
                workFlowInstance.AppId = "10105";
            }
            workFlowInstance.FormId = FormId;
            workFlowInstance.WfStatus = WfStatus;
            if (SumitTime != null)
            {
                workFlowInstance.SumitTime = SumitTime;
            }

            if (WfInstanceId != "")
            {
                workFlowInstance.WfInstanceId = WfInstanceId;
            }

            if (!isEdit)
            {
                result = wf_WorkFlowInstance.AddWorkFlowInstance(workFlowInstance);
            }
            else
            {
                result = wf_WorkFlowInstance.UpdateWorkFlowInstance(workFlowInstance);
            }
            FlowRelated1.ProcId = workFlowInstance.InstanceId;
            Countersign1.ProcId = workFlowInstance.InstanceId;
            Countersign1.SaveData(true);//会签数据保存
        }
        catch (Exception ex)
        {

            throw ex;
        }

        return result;
    }

    protected void Save_Click(object sender, EventArgs e)
    {
        PaymentApplicationInfo dataInfo = SaveFormData();

        if (dataInfo != null)
        {
            UploadAttachments1.SaveAttachment(FormId);

            if (SaveWorkFlowInstance("0", null, ""))
            {
                Alert("保存完成");
            }
        }
        else
        {
            Alert("保存失败");
        }
    }

    public void Alert(string msg)
    {
        DisplayMessage.ExecuteJs(string.Format("alert('{0}');", msg));
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect(ViewState["BackUrl"].ToString(), false);
    }

    protected void Submit_Click(object sender, EventArgs e)
    {
        int wfInstanceId = 0; //process instance id
        string id = ViewState["FormID"].ToString();

        PaymentApplicationInfo dataInfo = SaveFormData();
        //Countersign1.SaveData(true);//会签数据保存

        if (dataInfo != null)
        {
            UploadAttachments1.SaveAttachment(FormId);
            // Countersign1.SaveAndSubmit();//会签数据保存

            #region 工作流参数
            NameValueCollection dataFields = SetWFParams();
            if (dataFields == null)
            {
                return;
            }
            #endregion
            WorkflowHelper.CurrentUser = "founder\\" + _BPMContext.CurrentUser.LoginId;
            AppDict appInfo = new Pkurg.BPM.Services.AppDictService().GetByAppId("10105");
            if (appInfo == null)
            {
                Alert("提交失败");
                return;
            }
            WorkflowHelper.StartProcess(appInfo.WorkFlowName, FormId, dataFields, ref wfInstanceId);
            if (wfInstanceId > 0)
            {
                if (SaveWorkFlowInstance("1", DateTime.Now, wfInstanceId.ToString()))
                {
                    SaveWorkItem();
                    NotifyErpStart();
                    DisplayMessage.ExecuteJs("alert('提交成功'); window.close();");
                    return;
                }
            }
        }

        Alert("提交失败");

        //WorkflowHelper.ApproveProcess
        //insert data to business object
    }

    private void NotifyErpStart()
    {
        PaymentApplicationInfo info = PaymentApplication.GetPaymentApplicationInfo(FormId);
        new ERP_PaymentApplication_Service().NotifyStart(info.ErpFormId);
    }

    private void SaveWorkItem()
    {
        WorkFlowInstance workFlowInstance = wf_WorkFlowInstance.GetWorkFlowInstanceByFormId(FormId);

        ApprovalRecord appRecord = new ApprovalRecord()
        {
            ApprovalId = Guid.NewGuid().ToString(),
            WfTaskId = 0,
            FormId = FormId,
            InstanceId = workFlowInstance.InstanceId,
            Opinion = "",
            ApproveAtTime = DateTime.Now,
            ApproveResult = "",//开始
            OpinionType = "",
            CurrentActiveName = "拟稿",
            IsSign = "0",
            CurrentActiveId = "0",
            DelegateUserName = "",
            DelegateUserCode = "",
            CreateAtTime = DateTime.Now,
            UpdateAtTime = DateTime.Now,
            FinishedTime = DateTime.Now,
            ApproveByUserCode = _BPMContext.CurrentPWordUser.EmployeeCode,
            ApproveByUserName = _BPMContext.CurrentPWordUser.EmployeeName
        };

        new BFApprovalRecord().AddApprovalRecord(appRecord);
    }

    #endregion

    protected void ddlDepartName_SelectedIndexChanged(object sender, EventArgs e)
    {
        Countersign1.CounterSignDeptId = ddlDepartName.SelectedItem.Value;
        Countersign1.Refresh();
        LoadRelationPerson();
    }
    protected void cbPayer_CheckedChanged(object sender, EventArgs e)
    {
        cbRelatonUsers.Visible = cbPayer.Checked;
    }

    void Alert(Page page, object message)
    {
        StringBuilder sb = new StringBuilder();
        //改变鼠标的样式
        string js = string.Format(@"alert('{0}');", message) + sb.ToString();
        ScriptManager.RegisterStartupScript(page, page.GetType(), "ajax", js, true);
    }
    protected void lbDelete_Click(object sender, EventArgs e)
    {
        if (_BPMContext.ProcInst != null)
        {
            new WF_WorkFlowInstance().UpdateNowStatusByFormID(FormId, "5");
            DisplayMessage.ExecuteJs("alert('操作成功'); window.close();");
        }
        else
        {
            DisplayMessage.ExecuteJs("window.close();");
        }
    }
}
